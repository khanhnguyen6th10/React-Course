import { connect } from 'react-redux';
import { createUser } from '../../actions/user';
import Header from '../../Pages/Header/Header';

const mapStateToProps = (state) => ({
	userList: state.users,
})

const mapDispatchToProps = {
	createUser: createUser.start,
}

const UserModal = connect(
	mapStateToProps,
	mapDispatchToProps,
)(Header);

export default UserModal;