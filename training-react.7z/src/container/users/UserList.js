import { connect } from 'react-redux';
import Body from '../../Pages/Body/Body';
import { getUserList, createUser, editUser, delUser } from '../../actions/user';


const mapStateToProps = (state) => ({
	userList: state.users,
	currentPage: state.currentPage,
})

const mapDispatchToProps = {
	getUserList: getUserList.start,
	createUser: createUser.start,
	editUser: editUser.start,
	deleteUser: delUser.start,
}

const UserList = connect(
	mapStateToProps,
	mapDispatchToProps
)(Body)

export default UserList;