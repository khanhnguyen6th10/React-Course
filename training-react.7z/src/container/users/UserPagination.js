import { connect } from 'react-redux';
import Footer from '../../Pages/Footer/Footer';
import { getPagination } from '../../actions/userPagination';


const mapStateToProps = (state) => ({
	userList: state.users,
	currentPage: state.currentPage,
})

const mapDispatchToProps = {
	getCurrentPage:getPagination.succeed,
}


const UserPagination = connect(
	mapStateToProps,
	mapDispatchToProps
)(Footer)

export default UserPagination;