import { connect } from 'react-redux';
import ModalForm from '../../Components/pages/Modal/Modal.js';

const mapStateToProps = (state) => ({
	userList: state.users,
})

const ModalUser = connect(
	mapStateToProps,
	null
)(ModalForm);

export default ModalUser;