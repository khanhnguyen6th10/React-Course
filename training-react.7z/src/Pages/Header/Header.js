import React, { useState, useCallback } from 'react';
import './Header.scss';
import '../../font-awesome/css/font-awesome.min.css';

import Button from '../../Components/Core/Button/Button';
// import UserModal from '../../container/Modal/Modal';
import ModalForm from '../../Components/pages/Modal/Modal.js';

const Header = ({ createUser, userList }) => {
	const [editorData, setEditorData] = useState();
	const [editorModalVisible, setEditorModalVisible] = useState(false);
	const [type, setType] = useState();

	const icon = <i style={{ fontSize: "22px" }} className="fa fa-plus-circle"></i>;
	const title = "Add new users";

	const addUser = useCallback(() => {
		setType("add");
		setEditorData(null);
		setEditorModalVisible(true);
	}, [])

	const isClose = useCallback(() => {
		setEditorModalVisible(false);
	}, [])

	const onDataChange = (oldData, newData) => {
		createUser(newData);
		setEditorModalVisible(false);
	}

	return (
		<div className="header">
			<div className="header-left">
				<label>User</label>
				<strong>Management</strong>
			</div>
			<div className="header-right">
				<Button icon={icon} title={title} onHandle={addUser} cls={'button-main'} />
			</div>
			<ModalForm type={type} dataSource={userList} isClose={isClose} data={editorData} isOpen={editorModalVisible} onCreate={onDataChange} onCancel ={isClose} />
		</div>
	)
}

export default Header;
