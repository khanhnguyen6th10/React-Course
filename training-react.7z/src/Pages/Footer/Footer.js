import React, { useEffect, useState } from 'react';
import './Footer.scss';
// import data from '../../FakeData/data.json';
// const users = data.users;

const Footer = ({ userList, getCurrentPage }) => {
	const [arrPagi, setArrPagi] = useState([]);
	const [currentPage, setCurrentPage] = useState(1);
	const [startPagination, setStartPagination] = useState();
	const [endPagination, setEndPagination] = useState();
	
	const limitPage = 5;
	const limitRecordOfPage = 3;
	const totalPage = Math.ceil(userList.length / limitRecordOfPage);

	let startIndex = null;
	let endIndex = null;
	let arrPagination = [];


	useEffect(() => {
		if (userList.length > 0) {
			renderPagination(currentPage);
		}
	}, [userList, currentPage])

	function choosePage(selectedPage) {
		if (selectedPage === currentPage) return;
		setCurrentPage(selectedPage);
		getCurrentPage(selectedPage);
		renderPagination(selectedPage);
	}

	function renderPagination(currentPage) {
		if (totalPage > limitPage) {
			if (currentPage > 2 && currentPage < totalPage - 1) {
				startIndex = currentPage - 2;
				endIndex = currentPage + 2;
			} else {
				if (currentPage === totalPage) {
					startIndex = currentPage - 4;
					endIndex = currentPage;
				} else if (currentPage === totalPage - 1) {
					startIndex = currentPage - 3;
					endIndex = totalPage;
				} else {
					startIndex = 1;
					endIndex = limitPage;
				}
			}
		} else {
			startIndex = 1;
			endIndex = totalPage;
		}

		if (startIndex > 1) {
			setStartPagination(<span><a href="/#" >First</a><a href="/#">...</a></span>);
		} else {
			setStartPagination(<a href="/#">First</a>)
		}
		if (endIndex < totalPage) {
			setEndPagination(<span><a href="/#" >...</a><a href="/#">Last</a></span>);
		} else {
			setEndPagination(<a href="/#">Last</a>);
		}

		for (let i = startIndex; i <= endIndex; i++) {
			arrPagination.push(i);
		}

		setArrPagi(arrPagination);

	}

	return (
		<div className="footer">
			<div className="footer-content">
				<div className="left-footer">
					<label id="status-pagination">Showing {limitRecordOfPage} out of {userList.length} entries</label>
				</div>
				<div className="right-footer">
					<div id="pagination">
						{startPagination}
						{arrPagi.map((item, index) => (
							<a className={(item === currentPage) ? "active-true" : ""} key={index} href="/#" onClick={() => choosePage(item)}>{item}</a>
						))}
						{endPagination}
					</div>
				</div>
			</div>
		</div>
	)
}

export default Footer;
