import React, { useState, useEffect } from 'react';
import './Body.scss';
// import data from '../../FakeData/data.json';
import Checkbox from '../../Components/Core/Checkbox/Checkbox';
import '../../font-awesome/css/font-awesome.min.css';
import avatar from '../../Asset/Image/nature.jpg';
import ModalForm from '../../Components/pages/Modal/Modal.js';
import DialogRender from '../../container/Dialog/Dialog';

const Body = ({ getUserList, userList, currentPage, editUser, deleteUser }) => {
	const [editorModalVisible, setEditorModalVisible] = useState(false);
	const [editorData, setEditorData] = useState();
	const [type, setType] = useState();

	const limitRecordOfPage = 3;
	let userListRender = userList.slice((currentPage - 1) * limitRecordOfPage, (currentPage * limitRecordOfPage) || userList.length);

	useEffect(() => {
		getUserList();
	}, [getUserList])

	// start checkbox
	let checkboxes = document.getElementsByName('check');
	function checkRow(index) {
		let itemRow = document.getElementById(index);
		itemRow.className = checkboxes[index].checked ? "active-true" : "";
	}

	function checkAll(event) {
		const checkedAll = event.target.checked;

		for (let i = 0; i < checkboxes.length; i++) {
			checkboxes[i].checked = checkedAll ? true : false;
			document.getElementById(i).className = checkboxes[i].checked ? "active-true" : "";
		}
	}
	// end checkbox

	function isClose() {
		setEditorModalVisible(false)
	}

	function showDialogDel(data) {
		setType("delete");
		setEditorData(data);
		setEditorModalVisible(true)
	}

	function showDialogEdit(data) {
		setType("edit");
		setEditorData(data);
		setEditorModalVisible(true)
	}

	function delUser() {
		deleteUser(editorData);
		setEditorModalVisible(false);
	}

	function updateUser(oldData, newData) {
		editUser(oldData, newData);
		setEditorModalVisible(false);
	}

	// useMemo(() => function, input)
	const listUsers = userListRender.map((user, index) => (
		<tr id={index} key={index}>
			<td>
				<Checkbox name={"check"} handleClick={() => checkRow(index)} />
			</td>
			<td>
				<img src={avatar} alt="no-img" />
				<label className=""> {user.name}</label>
			</td>
			<td>
				<label>{user.date_created}</label>
			</td>
			<td>
				<label>{user.role}</label>
			</td>
			<td>
				<span className="">
					<i className="fa fa-circle status"></i>
					<span>{user.status}</span>
				</span>
			</td>
			<td>
				<span className="action">
					<span onClick={() => showDialogEdit(user)} className="action-edit">
						<i className="fa fa-cog"></i>
					</span>
					<span onClick={() => showDialogDel(user)} className="action-del">
						<i className="fa fa-times-circle"></i>
					</span>
				</span>
			</td>
		</tr>
	))

	return (
		<div className="body">
			<table className="table">
				<thead>
					<tr>
						<th>
							<Checkbox handleClick={checkAll} />
						</th>
						<th><label>Name</label></th>
						<th><label>Date Created</label></th>
						<th><label>Role</label></th>
						<th><label>Status</label></th>
						<th><label>Action</label></th>
					</tr>
				</thead>
				<tbody id="tbody">
					{listUsers}
				</tbody>
			</table>
			<ModalForm
				type ={type} 
				dataSource = {userListRender} 
				data={editorData} 
				isClose={isClose} 
				isOpen={editorModalVisible} 
				onEdit = {updateUser} 
				onDel={delUser} 
				onCancel={isClose} />
			<DialogRender />
		</div>
	)
}

export default Body;
