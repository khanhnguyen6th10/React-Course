import { createReducer } from '../../utils/redux.js';

import {
	GET_USERS_PAGINATION,
} from '../../actions/userPagination';

function requestUserListPagination(state, currentPage) {
	return currentPage;
}

export default createReducer(1, {
	[GET_USERS_PAGINATION]: requestUserListPagination,
});