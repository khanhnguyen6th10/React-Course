import {
	GET_USERS_SUCCEED,
	GET_USERS_FAILED,
	CREATE_USERS_SUCCEED,
	CREATE_USERS_FAILED,
	EDIT_USERS_SUCCEED,
	EDIT_USERS_FAILED,
	DEL_USERS_SUCCEED,
	DEL_USERS_FAILED,
} from '../../actions/user';

const ui = (state = { dialog: null }, action) => {
	let message = "";
	switch (action.type) {
		case CREATE_USERS_FAILED:
			message = "Add failed !";
			return {
				...state,
				dialog: message
			}
		case EDIT_USERS_FAILED:
			message = "Update failed !";
			return {
				...state,
				dialog: message
			}
		case DEL_USERS_FAILED:
			message = "Delete failed !";
			return {
				...state,
				dialog: message
			}
		case CREATE_USERS_SUCCEED:
			message = "Add succeed !";
			return {
				...state,
				dialog: message
			}
		case EDIT_USERS_SUCCEED:
			message = "Edit succeed !";
			return {
				...state,
				dialog: message
			}
		case DEL_USERS_SUCCEED:
			message = "Delete succeed !";
			return {
				...state,
				dialog: message
			}
		default:
			return state;
	}
}


export default ui;
