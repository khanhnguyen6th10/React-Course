import { combineReducers } from "redux";
import users from './users';
import currentPage from './userPagination';
import ui from './dialog';

export default combineReducers({
	users,
	currentPage,
	ui,
})