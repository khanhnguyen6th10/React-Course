import { createReducer } from '../../utils/redux.js';

import {
	GET_USERS_SUCCEED,
	CREATE_USERS_SUCCEED,
	EDIT_USERS_SUCCEED,
	DEL_USERS_SUCCEED
} from '../../actions/user';

function requestUserListSuccess(state, userList) {
	return userList;
}

function creatUserSuccess(state, payload) {
	return [...state, payload];
}

function editUserSuccess(state, payload) {
	return state.map(item => (item.id === payload.id ? { ...item, ...payload } : item));
}

function delUserSuccess(state, payload) {
	return state.filter(item => item.id !== payload);
}

export default createReducer([], {
	[GET_USERS_SUCCEED]: requestUserListSuccess,
	[CREATE_USERS_SUCCEED]: creatUserSuccess,
	[EDIT_USERS_SUCCEED]: editUserSuccess,
	[DEL_USERS_SUCCEED]: delUserSuccess,
});