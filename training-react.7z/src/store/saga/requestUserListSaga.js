import { call, put, takeLatest } from 'redux-saga/effects';
import {
	GET_USERS_START,
	getUserList,
	CREATE_USERS_START,
	createUser,
	EDIT_USERS_START,
	editUser,
	delUser,
	DEL_USERS_START,
} from '../../actions/user.js';
import {
	getUsersFactory,
	createUserFactory,
	editUserFactory,
	delUserFactory,
} from '../../api/users.js';

function* requestUserListSaga() {
	try {
		const api = getUsersFactory();
		const response = yield call(api);

		yield put(getUserList.succeed(response));
	} catch (error) {
		yield put(getUserList.failed(error))
	}
}

function* createUserSaga(action) {
	const user = action.payload;
	try {
		const api = createUserFactory();

		const response = yield call(api, user);
		yield put(createUser.succeed(response));
	} catch (error) {
		yield put(createUser.failed(error));
	}
}

function* editUserSaga(action) {
	const oldUser = action.payload.oldUser;
	const newUser = action.payload.newUser;
	try {
		const api = editUserFactory();

		const response = yield call(api, oldUser, newUser);
		yield put(editUser.succeed(response));
	} catch (error) {
		yield put(editUser.failed(error));
	}
}

function* delUserSaga(action) {
	const id = action.payload.id;
	try {
		const api = delUserFactory();

		const response = yield call(api, id)
		yield put(delUser.succeed(response));
	} catch (error) {
		yield put(delUser.failed(error));
	}
}

export default function* watchGetUserList() {
	yield takeLatest(GET_USERS_START, requestUserListSaga);
	yield takeLatest(CREATE_USERS_START, createUserSaga);
	yield takeLatest(EDIT_USERS_START, editUserSaga);
	yield takeLatest(DEL_USERS_START, delUserSaga);
}