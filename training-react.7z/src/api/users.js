import axios from 'axios';

export const getUsersFactory = () => {
	const getUserList = async () => {
		const response = await axios.get('http://localhost:80/api/users/readUsers.php');
		if (response.status !== 200) {
			throw new Error('Get data failed !');
		}

		const result = response.data;
		return result;
	}
	return getUserList;
};


export const createUserFactory = () => {
	const createUser = async (user) => {
		const reqBody = user;
		const response = await axios.post('http://localhost:80/api/users/createUsers.php', reqBody, {
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
		});
		if (response.status !== 200) {
			throw new Error("Create user failed");
		}
		const result = response.data;
		console.log(result)
		return result;
	}
	return createUser;
}

export const editUserFactory = () => {
	const editUser = async (oldUser, newUser) => {
		const reqBody = newUser;
		const response = await axios.patch('http://localhost:80/api/users/updateUsers.php', reqBody,
			{ headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
		);

		if (response.status !== 200) {
			throw new Error("Create user failed");
		}
		const result = newUser;
		return result;
	}
	return editUser;
}
export const delUserFactory = () => {
	const delUser = async (id) => {
		const response = await axios.delete(`http://localhost:80/api/users/deleteUsers.php`,
			{ headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, data: { id } }
		);

		if (response.status !== 204) {
			throw new Error('Delete user failed');
		}
		return id;
	}
	return delUser;
}