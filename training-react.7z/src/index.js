import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';

import { Provider } from 'react-redux';
import createSagaMiddleware from 'redux-saga'
import rootReducer from './store/reducer';
import { createStore, compose, applyMiddleware } from 'redux';
import rootSaga from './store/saga';
require('dotenv').config();

// create store start

const composeEnhaners =
	typeof window === 'object' &&
		window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ?
		window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({
			// Specify extension’s options like name, actionsBlacklist, actionsCreators, serialize...
			trace: true,
			traceLimit: 15
		}) : compose;

const sagaMiddleware = createSagaMiddleware();
const store = createStore(
	rootReducer,
	composeEnhaners(
		applyMiddleware(
			sagaMiddleware,
		)
	)
);
sagaMiddleware.run(rootSaga);

ReactDOM.render(
	<Provider store={store}>
		<App />
	</Provider>,
	document.getElementById('root')
);

