export const GET_USERS_PAGINATION = 'GET_USERS_PAGINATION';

export const getPagination = {
	succeed: (currentPage) => ({
		type: GET_USERS_PAGINATION,
		payload: currentPage,
	}),
	
}