export const GET_USERS_START = 'GET_USERS_START';
export const GET_USERS_SUCCEED = 'GET_USERS_SUCCEED';
export const GET_USERS_FAILED = 'GET_USERS_FAILED';

export const CREATE_USERS_START = 'CREATE_USERS_START';
export const CREATE_USERS_SUCCEED = 'CREATE_USERS_SUCCEED';
export const CREATE_USERS_FAILED = 'CREATE_USERS_FAILED';

export const EDIT_USERS_START = 'EDIT_USERS_START';
export const EDIT_USERS_SUCCEED = 'EDIT_USERS_SUCCEED';
export const EDIT_USERS_FAILED = 'EDIT_USERS_FAILED';

export const DEL_USERS_START = 'DEL_USERS_START';
export const DEL_USERS_SUCCEED = 'DEL_USERS_SUCCEED';
export const DEL_USERS_FAILED = 'DEL_USERS_FAILED';


export const getUserList = {
	start: () => ({
		type: GET_USERS_START,
	}),

	succeed: (result) => ({
		type: GET_USERS_SUCCEED,
		payload: result,
	}),

	failed: (error) => ({
		type: GET_USERS_FAILED,
		payload: error,
	})
}

export const createUser = {
	start: (user) => ({
		type: CREATE_USERS_START,
		payload: user,
	}),

	succeed: (result) => ({
		type: CREATE_USERS_SUCCEED,
		payload: result,
	}),

	failed: (error) => ({
		type: CREATE_USERS_FAILED,
		payload: error,
	})
}

export const editUser = {
	start: (oldUser, newUser) => ({
		type: EDIT_USERS_START,
		payload: {oldUser, newUser}
	}),

	succeed: (result) => ({
		type: EDIT_USERS_SUCCEED,
		payload: result,
	}),

	failed: (error) => ({
		type: EDIT_USERS_FAILED,
		payload: error,
	})
}

export const delUser = {
	start: (user) => ({
		type: DEL_USERS_START,
		payload: user,
	}),

	succeed: (result) => ({
		type: DEL_USERS_SUCCEED,
		payload: result,
	}),

	failed: (error) => ({
		type: DEL_USERS_FAILED,
		payload: error,
	})
}