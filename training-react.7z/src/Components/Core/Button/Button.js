import React from 'react';
import './Button.scss';
const Button = ({ icon, onHandle, title, cls }) => {
	return (
		<span className='container-btn'>
			<button onClick = {onHandle} className ={cls}>
				<span className='icon'>{icon} </span>
				<span className='title'>{title}</span>
			</button>
		</span>
	)
}
export default Button;