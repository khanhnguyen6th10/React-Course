import React from 'react'
import './Checkbox.scss';

const Checkbox = ({ handleClick, name }) => {
	return (
		<label onChange={handleClick} className="container">
			<input type="checkbox" name={name} />
			<span className="checkmark"></span>
		</label>
	)
}
export default Checkbox;