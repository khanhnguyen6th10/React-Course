import React from 'react'
import './Input.scss';

const Input = ({ onChange, item, ...props }) => {
	function handleChange(e) {
		onChange && onChange(e, item);
	}
	return (
		<div className="container-input">
			<input onChange={handleChange} {...props} className="inputText" type="text" />
		</div>
	)
}
export default Input