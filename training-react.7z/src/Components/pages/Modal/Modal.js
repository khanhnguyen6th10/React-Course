import React, { useState, useEffect } from 'react';
import './Modal.scss';
import Modal from 'react-modal';
import Button from '../../Core/Button/Button.js';
import Input from '../../Core/Input/Input.js';
import DialogRender from '../../../container/Dialog/Dialog';
import { put } from 'redux-saga/effects';

// Modal.setAppElement('el');
Modal.setAppElement('#root');

const customStyle = {
	content: {
		top: '40%',
		left: '50%',
		bottom: 'auto',
		right: 'auto',
		width: '500px',
		transform: 'translate(-50%, -50%)',
	}
}

const ModalForm = ({ isOpen, isClose, onCancel, dataSource, data, onDel, onCreate, onEdit, type }) => {
	const [formData, setFormData] = useState({});
	const [err, setErr] = useState(false);
	useEffect(() => {
		if (data == null) {
			setFormData({})
		} else {
			if (data) {
				setFormData({ ...data })
			}
		}
	}, [data])


	let listField = [];
	let newListField = [];
	if (dataSource !== undefined) {
		const newObj = dataSource[0];
		if (newObj !== undefined) {
			listField = Object.getOwnPropertyNames(newObj);
			newListField = listField.slice(1, listField.length - 1);
		}
	}

	const handleInputChange = (e, item) => {
		let valueInput = e.target.value;
		setFormData({ ...formData, [item]: valueInput });
	}

	const components = (item) => {
		let value = '';
		if (formData) {
			value = formData[item] || '';
		}
		return (
			<Input
				placeholder={item}
				value={value}
				onChange={handleInputChange}
				item={item}
			/>
		)
	}
	const onDataSubmit = (e) => {
		e.preventDefault();
		let newData = { ...formData };
		
		let newArr = Object.values(newData);
		if (newArr.length < newListField.length) {
			setErr(true);
			return
		}

		if (type === "delete") {
			onDel(data);
		} else if (type === "edit") {
			onEdit && onEdit(data, newData);
		} else {
			onCreate && onCreate(data, newData);
		}
	}
	function closeDialog() {
		setErr(false);
	}

	let titleForm = "";
	let titleBtn = "";
	let bodyForm;
	if (type === "edit") {
		titleForm = "EDIT USER";
		titleBtn = "EDIT"
		bodyForm = newListField.map((item, index) => (
			<div key={index}>
				<div className="col-25">
					<span>{item}</span>
				</div>
				<div className="col-75">
					{components(item)}
				</div>
			</div>
		));
	} else if (type === "delete") {
		titleForm = "DELETE USER";
		titleBtn = "DELETE";
		bodyForm = <div className="delete-item">Do you want to delete this user ?</div>;
	} else if (type === "add") {
		titleForm = "ADD NEW USER";
		titleBtn = "ADD";
		bodyForm = newListField.map((item, index) => (
			<div key={index}>
				<div className="col-25">
					<span>{item}</span>
				</div>
				<div className="col-75">
					{components(item)}
				</div>
			</div>
		));
	}

	return (
		<div id="container-modal">
			<Modal
				isOpen={isOpen}
				style={customStyle}
			>
				<div className="modal">
					<div className="modal-header">
						<span onClick={isClose} className="close">&times;</span>
						<label>{titleForm}</label>
					</div>
					<div className="modal-body">
						{bodyForm}
					</div>
					<div className="modal-footer">
						<Button cls="button-submit" title={titleBtn} onHandle={onDataSubmit} />
						<Button cls="button-cancel" title="CANCEL" onHandle={onCancel} />
					</div>
				</div>
			</Modal>
			<Modal
				style ={customStyle}
				id="err-dialog"
				isOpen={err}
			>
				<div id="content-dialog">Không được để trống !</div>
				<div className="footer-dialog">
					<Button cls={"button-submit"} title ={"OK"} onHandle={closeDialog}/>
				</div>
			</Modal>
		</div>
	)
}
export default ModalForm;
