import React, { useState, useEffect } from 'react';
import './Dialog.scss';

import Button from '../../Core/Button/Button';
import Modal from 'react-modal';

const Dialog = ({ message }) => {
	const [isOpen, setIsOpen] = useState(false);

	const customStyle = {
		content: {
			top: '40%',
			left: '50%',
			bottom: 'auto',
			right: 'auto',
			width: '300px',
			transform: 'translate(-50%, -50%)',
		}
	}

	useEffect(() => {
		if (message !== null) {
			setIsOpen(true);
		}
	}, [message])

	function closeDialog() {
		setIsOpen(false);
	}
	return (
		<div>
			<Modal style={customStyle} isOpen={isOpen}>
				<div className="content-dialog">
					{message}
				</div>
				<div className="footer-dialog">
					<Button onHandle={closeDialog} cls={'button-submit'} title="OK" />
				</div>
			</Modal>
		</div>
	)
}

export default Dialog;
