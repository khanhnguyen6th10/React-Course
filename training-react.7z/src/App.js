import React from 'react';
import './App.css';
import Header from './container/users/UserModal';
// import Header from './Pages/Header/Header';
import Footer from './container/users/UserPagination';
import UserList from './container/users/UserList';

function App() {
	
	return (
		<div className="App">
			<Header />
			<UserList />
			<Footer />
		</div>
	);
}

export default App;
